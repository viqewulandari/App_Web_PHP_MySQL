
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Manajemen Dosen dan prodi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="hura.css?<?= time();?>">
   <link rel="icon" href="logo.png">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
   
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link link_aktif" href="#">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="prodi.php">INPUT PRODI</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dosen.php">INPUT DOSEN</a>
        </li>  
        
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid mt-3">
  <h3>Daftar Prodi</h3>
</div>
<table cellpadding="10" cellspacing="0" width="100%">
  <tr>
  <th>NO</th>
  <th>FAKULTAS</th>
  <th>KODE PRODI</th>
  <th>NAMA PRODI</th>
  <th>TINDAKAN</th>
</tr>
  <?php 
$coon=mysqli_connect("localhost","root","","simdosen");
$q=mysqli_query($coon,"SELECT * FROM  tabelprodi");
$i=1;
while ($row=mysqli_fetch_assoc($q)):
   ?>
<tr>

  <td><?=$i; ?></td>
  <td><?= $row["fakultas"];?></td>
  <td><?= $row["kodeprodi"];?></td>
  <td><?= $row["namaprodi"];?></td>
  <td><a href="hapus.php?r=<?=$row['kodeprodi'];?>" onclick="confirm('yakin.?')">Hapus</a></td>
</tr>
<?php $i++; ?>
<?php endwhile; ?>

</table>
<br>
<div class="container-fluid mt-3">
  <h3>Daftar Dosen</h3>
</div>
<table cellpadding="10" cellspacing="0" width="100%">
  <tr>
  <th>NO</th>
  <th>NAMA DOSEN</th>
  <th>NIDN DOSEN</th>
  <th>ALAMAT</th>
  <th>NO HP</th>
  <th>KODE PRODI</th>
  <th>TINDAKAN</th>
</tr>
  <?php 
$coon=mysqli_connect("localhost","root","","simdosen");
$q=mysqli_query($coon,"SELECT * FROM  tabeldosen");
$i=1;
while ($row=mysqli_fetch_assoc($q)):
   ?>
<tr>

  <td><?=$i; ?></td>
  <td><?= $row["namadosen"];?></td>
  <td><?= $row["idndosen"];?></td>
  <td><?= $row["alamat"];?></td>
  <td><?= $row["nohp"];?></td>
  <td><?= $row["kodeprodi"];?></td>
  <td><a href="hapus.php?i=<?=$row['idndosen'];?>" onclick="confirm('yakin.?')">Hapus</a></td>
  
</tr>
<?php $i++; ?>
<?php endwhile; ?>

</table>

</body>
</html>
