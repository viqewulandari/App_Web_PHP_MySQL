<!DOCTYPE html>
<html lang="en">
<head>
  <title>Input Data Prodi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="hura.css?<?= time();?>">
  <link rel="icon" href="logo.png">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
   
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link " href="index.php">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link link_aktif" href="#"> INPUT PRODI</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dosen.php"> INPUT DOSEN</a>
        </li>  
        
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-3">
  <h3>DATA PRODI</h3>
    
  <form action="#" method="post">
    <div class="mb-3 mt-3">
      <label for="nama_fakultas" class="form-label">NAMA FAKULTAS:</label>
      <input type="text" class="form-control" id="nama_fakultas" placeholder="Enter nama fakultas" name="nama_fakultas" required>
     
    </div>
    <div class="mb-3">
      <label for="kode_prodi" class="form-label">KODE PRODI:</label>
      <input type="text" class="form-control" id="pwd" placeholder="Enter kode prodi" name="kode_prodi" required>
    
    </div>
    <div class="mb-3">
      <label for="prodi" class="form-label">NAMA PRODI:</label>
      <input type="text" class="form-control" id="pwd" placeholder="Enter prodi" name="prodi" required>
     </div>
  <button type="submit" class="btn btn-primary" name="kirim">Submit</button>
  </form>
</div>



</body>
</html>

<?php 
if (isset($_POST["kirim"])):
  $coon=mysqli_connect("localhost","root","","simdosen");
  $nama_fakultas=$_POST["nama_fakultas"];
  $kode_prodi=$_POST["kode_prodi"];
  $prodi=$_POST["prodi"];
  $ex=mysqli_query($coon,"INSERT INTO tabelprodi VALUES ('$nama_fakultas','$kode_prodi','$prodi');");
   if($ex>0):
  echo "Record Berhasil Ditambah";
else:
  echo "Record gagal Ditambah";
endif;
endif;



 ?>