<?php 
$coon=mysqli_connect("localhost","root","","simdosen");
if(isset($_GET['r'])):
$rr=$_GET['r'];
$q=mysqli_query($coon,"SELECT * FROM  tabelprodi WHERE kodeprodi='$rr' ");
if($q->num_rows>0):
$ex=mysqli_query($coon,"DELETE FROM tabelprodi WHERE kodeprodi='$rr' ");
if($ex>0):
echo "<script> alert('data prodi berhasil dihapus');
document.location.href='index.php';
</script>

";
endif;
endif;

elseif(isset($_GET['i'])):
$ii=$_GET['i'];
$q=mysqli_query($coon,"SELECT * FROM  tabeldosen WHERE idndosen='$ii' ");
if($q->num_rows>0):
$ex=mysqli_query($coon,"DELETE FROM tabeldosen WHERE idndosen='$ii' ");
if($ex>0):
echo "<script> alert('data dosen berhasil dihapus');
document.location.href='index.php';
</script>";
endif;
endif;
else:
echo "<script> alert('data prodi berhasil dihapus');
document.location.href='index.php';
</script>

";
endif;


 ?>
